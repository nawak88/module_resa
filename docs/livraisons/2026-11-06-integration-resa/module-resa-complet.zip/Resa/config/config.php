<?php

return [
    'name' => 'Resa',
];
